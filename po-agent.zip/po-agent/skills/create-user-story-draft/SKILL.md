---
name: create-user-story-draft
description: >
  Drafts or revises ONE governed user story for the PO orchestration flow and
  returns it in chat as Markdown (never JSON unless explicitly requested).
  Invoke only from the Product Owner Orchestration Agent, after the parent EPIC
  has been completed and `knowledge-base-usage` has run for ARTEFACT_TYPE =
  USER_STORY. Never invents IDs, ownership, priority, architecture, APIs,
  targets, approvals, compliance evidence or coverage.
---

# Create User Story Draft

## Inputs (provided by the orchestrator)
- `INITIATIVE_ID`
- `EPIC_ID` and `EPIC_CONTENT` — the persisted parent epic. Keep the story
  consistent with its scope, out of scope and acceptance criteria.
- `US_ID` and `US_TITLE` — from the outline. Use exactly; never generate or
  renumber.
- `GUIDELINES` — output of `knowledge-base-usage`. Apply them.
- `INITIATIVE_CONTEXT` — initiative summary and relevant source sections.
- `DATE` — if missing, `Not provided`.
- Optional: `CURRENT_DRAFT` + `REQUESTED_CHANGES`.

If `US_ID` or `EPIC_ID` is missing, return
`STATUS: FAILED — missing <input>` and do not draft.

## Mode selection
- No CURRENT_DRAFT → **Create**.
- CURRENT_DRAFT + REQUESTED_CHANGES → **Update**: apply only the requested
  changes, preserve everything else and all history rows, increment the
  version, add one Version History row.
- **Validate** only when the user explicitly asks to validate a story. Never
  in the normal flow. Validate reports: overall result, blocking issues,
  warnings, evidence gaps, consistency issues, recommended corrections (by
  section). It does not rewrite the story unless asked.

## Source rules
- Facts come only from user input, INITIATIVE_CONTEXT, EPIC_CONTENT and
  GUIDELINES. Internally classify information as Confirmed, Assumption,
  Proposed, Missing or Conflicting; only Confirmed is stated as fact.
- Never invent: epic or story IDs; priority, status, assignee, sprint; authors,
  reviewers, approvals; architecture or design decisions; AWS resources;
  services, APIs, methods or paths; performance, retention or coverage targets;
  compliance or security evidence; scan results or vulnerabilities.
- Never infer ownership from authorship, meetings, team or expertise.
- If sources conflict, state the conflict; do not pick silently.
- Only synthetic examples and test data. Never expose credentials, secrets,
  tokens, production records or personal data.

## Missing-information states
- `Not provided` — unknown requirement or administrative data
- `Not yet assigned` — assignee or sprint
- `Not verified` — evidence-dependent data (does not mean the control failed)
- `None confirmed` — no authoritative item (does not prove none exists)
- `Not applicable` — the section genuinely does not apply

## Section rules
- **User Story**: "As a [role], I want [capability], so that [business value]"
  — one role, one capability, one outcome; business value, not implementation.
- **Description**: adds context, expected behaviour, boundaries and rationale;
  does not repeat the story sentence.
- **Design**: only from confirmed information or an authoritative reference.
- **Preconditions / Assumptions / Out of Scope / Entry Points / Success Flow**:
  keep separate. Success Flow is an ordered list with no failure branches.
- **Data Model**: confirmed fields only, exact names, explicit types,
  Required = `Yes` / `No` / `Conditional: [condition]`, synthetic examples.
- **Validation Rules**: one per testable constraint; precise formats, bounds,
  allowed values; names match the Data Model. Do not invent error-code schemes.
- **Error Handling**: applicable cases (invalid input, authN/authZ, missing
  resource, conflict, dependency failure, throttling, timeout, unexpected).
  Documented HTTP statuses only. Never expose stack traces, secrets, topology
  or query text.
- **APIs and AWS**: confirmed items only. Methods uppercase, paths start with
  `/`, consistent path variables (`{customerId}`), aligned with Entry Points.
- **Acceptance Criteria**: `AC-P-01…` positive, `AC-N-01…` negative,
  Given / When / Then, independently testable. Negative cases align with
  Validation Rules and Error Handling.
- **Tests**: numbered from 1; each has objective, ACs covered, setup, synthetic
  input and exact observable result (never "works" or "passes").
- **Non-Functional Requirements**: confirmed or approved only; never invent
  latency, throughput, availability, retention or coverage targets.
- **Compliance / Security**: a control is complete only with authoritative
  evidence; otherwise `Not verified`. Planned is not verified.
- **Coverage / Vulnerabilities**: keep required coverage, tool, measured
  coverage and exclusions separate; a target is not a measurement. "Zero
  vulnerabilities" only from an authoritative scan.
- **Dependencies**: confirmed only; preserve type and status.
- **Governance**: Definition of Ready only from an authoritative reference.
  Version History in `YYYY-MM-DD`, oldest to newest, monotonic versions, what
  changed and why. Acceptance History only for a real formal acceptance
  decision whose version exists in Version History.

## Output structure
Always start with the header below, then every section in this order.
Keep every heading. When a section has no confirmed content, write one line
with the applicable state. Never omit a section and never create placeholder
table rows.

# USER STORY — {US_ID} — {US_TITLE}
**Epic:** {EPIC_ID} | **Initiative:** {INITIATIVE_ID} | **Version:** {VERSION} | **Status:** Draft

## Metadata
## User Story
## Description
## Design
## Preconditions and Scope
### Preconditions
### Assumptions
### Out of Scope
### Entry Points
## AWS Resources
## Success Flow
## Data Model
## Validation Rules
## Error Handling
## API Description
### Services Consumed
### Endpoints Implemented
## Acceptance Criteria
### Positive Cases
### Negative Cases
## Test Cases & Test Data
## Non-Functional Requirements
## Compliance
## Security Compliance
## Unit Test Coverage
## Dependency Vulnerabilities
## Unresolvable Vulnerabilities
## Dependencies
## Definition of Ready
## Version History
## Acceptance History
## Notes
## Assumptions and Gaps

Formatting: short narrative for descriptions; bullets for scope; numbered list
for Success Flow; tables for structured records; Given / When / Then for ACs;
checklists for compliance controls; JSON code blocks only for
request / response / test examples.

## Final check
Before responding verify: header and section order; role, capability and
value are clear; IDs exactly as provided; nothing invented; Success Flow has no
failure branches; Data Model, Validation Rules and Error Handling align; APIs
align with Entry Points; ACs unique and testable; tests trace to ACs; no
control marked complete without evidence; only synthetic data; gaps visible.

## Response rules
Return the draft directly in chat as a reviewable draft, not as final or
approved. Do not expose internal reasoning. Never make the story look more
certain, complete or approved than the evidence supports.
