---
name: retrieve-initiative
description: >
  Retrieves the persisted state of an existing initiative from SharePoint
  (outline, folder path, completed EPICs and USER STORIES) so the PO flow can
  resume. Invoke only from the Product Owner Orchestration Agent when the user
  chooses to resume an initiative and has provided its Initiative ID.
---

# Retrieve Initiative

## Purpose
Rebuild the orchestrator's state for an existing initiative from what is
actually stored in SharePoint. Never reconstruct state from memory or from the
conversation.

## Inputs
- `INITIATIVE_ID` — required. If missing, return
  `STATUS: FAILED — missing INITIATIVE_ID` and do not call any flow.

## Procedure
1. Call `PO_FLOW_CONTINUE_INITIATIVE` with:
   - `text` → INITIATIVE_ID
2. If the flow fails, returns nothing, or reports that the initiative does not
   exist, return `STATUS: FAILED — <reason returned by the flow>`. Do not guess.
3. From the flow result, extract:
   - The initiative outline document (Initiative Summary + Preliminary Backlog).
   - The initiative `FOLDER_PATH`.
   - The list of files stored in `EPICS/` and `USER STORIES/`.
4. Parse the outline:
   - Epics: lines matching `## EPIC-NNN — {title}` plus the `**Scope:**` line below.
   - User stories: lines matching `- US-NNN — {title}`; the parent is the
     nearest `## EPIC-NNN` heading above.
5. Determine completion:
   - An artefact is COMPLETED only if a file whose name starts with its ID
     followed by a hyphen exists in the matching folder
     (e.g. `EPIC-001-Customer-Onboarding.md` in `EPICS/`,
     `US-003-Search-Catalogue.md` in `USER STORIES/`).
   - Match the full ID (`US-001-` must not match `US-0010-`).
   - Anything without a matching file is PENDING.
6. Validate:
   - Every user story has a parent epic in the outline.
   - Flag files whose ID is not in the outline as `UNKNOWN_FILES`. Do not
     delete or modify them.
   - Flag a completed user story whose parent epic is not completed as an
     inconsistency.

## Rules
- Do not create, modify or delete anything in SharePoint.
- Do not infer completion from drafts, conversation history or status fields
  inside documents. Only stored files count.
- Do not invent IDs, titles or paths.

## Output
Return exactly this structure to the orchestrator:

STATUS: SUCCESS | FAILED — {reason}
INITIATIVE_ID: {id}
FOLDER_PATH: {path returned by the flow}

## OUTLINE
{full outline text as stored}

## EPICS
| ID | Title | Scope | Status |
|---|---|---|---|
| EPIC-001 | {title} | {scope} | COMPLETED / PENDING |

## USER_STORIES
| ID | Title | Parent Epic | Status |
|---|---|---|---|
| US-001 | {title} | EPIC-001 | COMPLETED / PENDING |

## COMPLETED_IDS
{comma-separated IDs}

## WARNINGS
- {unknown files, inconsistencies} (omit section if none)

## Assumptions to verify (remove once confirmed)
- `PO_FLOW_CONTINUE_INITIATIVE` takes the Initiative ID as `text` and returns
  the outline content, the folder path and the file list of `EPICS/` and
  `USER STORIES/`. If it returns something different, adjust Procedure step 3.
