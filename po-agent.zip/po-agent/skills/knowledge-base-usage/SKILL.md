---
name: knowledge-base-usage
description: >
  Retrieves the VWFS guidelines that apply to a Product Owner artefact
  (OUTLINE, EPIC or USER_STORY) from the agent's knowledge sources and returns
  them as a concise GUIDELINES digest. Invoke only from the Product Owner
  Orchestration Agent, before any drafting skill. Does not draft artefacts.
---

# Knowledge Base Usage

## Purpose
Give the drafting skills the VWFS rules they must follow, so every artefact
conforms to the organisation's guidelines.

## Inputs
- `ARTEFACT_TYPE` — `OUTLINE`, `EPIC` or `USER_STORY`. Required.
- Optional: `TOPIC_HINTS` — domain keywords from the initiative (e.g. "payments",
  "customer onboarding") to retrieve domain-specific guidance.

If ARTEFACT_TYPE is missing, return `STATUS: FAILED — missing ARTEFACT_TYPE`.

## Procedure
1. Search the configured knowledge sources for guidance relevant to
   ARTEFACT_TYPE:
   - naming and title conventions
   - mandatory sections and templates
   - acceptance-criteria rules
   - Definition of Ready / Definition of Done
   - security, privacy, compliance and regulatory requirements
   - language and style rules
2. If TOPIC_HINTS are provided, also search for domain-specific guidance.
3. Keep only rules that apply to ARTEFACT_TYPE.
4. When two sources conflict, keep both and flag the conflict.

## Rules
- Use only what the knowledge sources actually contain. Never invent a
  guideline, template, threshold or policy.
- Reference each rule by its source document name (and section when known).
- Do not copy whole documents; extract the applicable rules.
- Do not expose confidential content that is not needed for drafting.

## Output
Return exactly this structure:

# GUIDELINES — {ARTEFACT_TYPE}
**Status:** FOUND | PARTIAL | NOT FOUND

## Rules
- {rule} — _Source: {document}, {section}_

## Conflicts
- {conflict} (omit section if none)

## Not covered
- {topic with no guideline found} (omit section if none)

If nothing relevant is found, return `Status: NOT FOUND` with an empty Rules
section. The orchestrator continues without guidelines and tells the user.
