---
name: initiative-to-epic-draft
description: >
  Drafts or revises ONE EPIC from an approved initiative outline and returns
  the full draft in chat as Markdown. Invoke only from the Product Owner
  Orchestration Agent, after `initiative-backlog-outline` has been published
  and `knowledge-base-usage` has run for ARTEFACT_TYPE = EPIC.
---

# Initiative to EPIC Draft

## Purpose
Turn one epic from the approved outline into a clear, traceable EPIC draft
for product, architecture, engineering, security, compliance and delivery
review. Content must come from the initiative; facts and assumptions must be
kept apart.

## Inputs (provided by the orchestrator)
- `INITIATIVE_ID` — use as the project key. Never derive another key.
- `INITIATIVE_DOCUMENT` — or the outline if the document is not available.
- `TARGET_EPIC` — ID, title and scope from the outline. Use exactly.
- `TARGET_USER_STORIES` — IDs and titles of this epic's stories from the
  outline. Use exactly; never add, rename, renumber or merge.
- `GUIDELINES` — output of `knowledge-base-usage`. Apply them.
- `FOLDER_PATH` — SharePoint folder of the initiative. If missing, `TBD`.
  Never invent it.
- `DATE` — if missing, `TBD`.
- Optional: `CURRENT_DRAFT` + `REQUESTED_CHANGES` → Revise mode.

If `TARGET_EPIC` is missing, return `STATUS: FAILED — missing TARGET_EPIC`
and do not draft. Never decompose the initiative into epics yourself.

## Modes
- **Create** (no CURRENT_DRAFT): Steps 1–6, version `0.1`.
- **Revise** (CURRENT_DRAFT + REQUESTED_CHANGES):
  - Apply only the requested changes; keep every other section as is.
  - Do not regenerate from the source.
  - Increment the version (0.1 → 0.2 → 0.3…) and add a Version History row
    describing the change.
  - If a change contradicts the initiative, apply it and record the
    contradiction in Open Questions.

## Workflow (Create mode)

### Step 1: Read the source
Read the initiative sections relevant to TARGET_EPIC: purpose, problem,
outcomes, stakeholders, capabilities, non-functional requirements, systems
and repositories, interfaces, ownership, dependencies, security / privacy /
legal / audit / compliance requirements, regional scope, exclusions, success
measures. Do not add facts from general knowledge.

### Step 2: Metadata
- `PROJECT_NAME`: initiative name from the source; if absent, a working title
  flagged in Open Questions.
- `REGION`: as stated, otherwise `TBD`.
- `AUTHORS`: as stated, otherwise `TBD`. Never infer from file ownership.

### Step 3: Acceptance criteria (EPIC level)
- Observable, testable outcomes covering the epic as a whole.
- Include functional, integration, security, privacy, operational, audit and
  regional conditions when the source supports them.
- Preserve measurable thresholds exactly. If one is needed but missing:
  `TBD: Define the measurable threshold for [quality or outcome].`
- No vague wording ("works well", "user-friendly") without a measure.

### Step 4: Traceability
Under Document References, cite the source file, title, section or URL and
what each supports. Never invent page numbers, sections, URLs or titles.

### Step 5: User stories table
List exactly TARGET_USER_STORIES. Priority `TBD` unless the source states
one; Status `Draft`. Story count = number of rows.

### Step 6: Quality check
Before responding verify: template order; traceability; no unsupported
claims; IDs exactly as provided; story count correct; scope vs out-of-scope
consistent; criteria testable; source-stated privacy / security / compliance /
regional concerns covered; no unnecessary sensitive data. Fix issues first.

## Content rules
- **Executive Summary**: 2–4 short paragraphs — problem, intended outcome of
  this epic, how it fits the initiative, key constraints or uncertainties.
  No promotional claims.
- **Terminology**: only initiative-defined, domain-specific or ambiguous terms.
  If none: `| TBD | No initiative-specific terminology was identified. |`
- **Repository Topology / Ownership / Contracts**: only explicitly named items;
  otherwise one `TBD` row. Never infer owners from job titles or authorship.
  Never print secrets, credentials, tokens or personal data.
- **Out of Scope**: only stated exclusions; otherwise
  `TBD: Confirm exclusions and deferred capabilities.`
- **Dependencies**: only supported ones; otherwise
  `TBD: Confirm upstream, downstream, organisational, and external dependencies.`
- **Open Questions**: only material, unresolved items, each naming the field it
  affects. Omit the section if there are none.

## Output requirements
Return one short sentence saying this is a draft based on the initiative,
then the complete document below. Do not claim tickets or files were created,
do not return JSON, do not wrap the document in a code block, do not omit
sections.

## Required output template

# EPIC — {TARGET_EPIC.ID} — {TARGET_EPIC.TITLE}

**Initiative:** {INITIATIVE_ID} — {PROJECT_NAME}
**Version:** {VERSION}
**Date:** {DATE}
**Region:** {REGION}
**Authors:** {AUTHORS}
**SharePoint:** {FOLDER_PATH_OR_TBD}

---

## Executive Summary

{SOURCE_BACKED_SUMMARY}

## Terminology

| Term | Meaning |
|------|---------|
| {TERM_OR_TBD} | {MEANING} |

## Repository Topology

| Repository | Purpose | Framework | Org |
|-----------|---------|-----------|-----|
| {REPOSITORY_OR_TBD} | {PURPOSE_OR_TBD} | {FRAMEWORK_OR_TBD} | {ORG_OR_TBD} |

### Resource ownership matrix

| Resource | Owner |
|----------|-------|
| {RESOURCE_OR_TBD} | {OWNER_OR_TBD} |

### Cross-repository contracts

| Value | Key / mechanism | Consumed by |
|-------|----------------|-------------|
| {VALUE_OR_TBD} | {KEY_OR_MECHANISM_OR_TBD} | {CONSUMER_OR_TBD} |

## Description

{Outcome delivered, problem addressed, who benefits, why it is one epic}

## Scope

- {IN_SCOPE_ITEM}

## Out of Scope

- {OUT_OF_SCOPE_ITEM_OR_TBD}

## User Stories

| US ID | Title | Priority | Status |
|-------|-------|----------|--------|
| {US_ID} | {US_TITLE} | {MUST_SHOULD_COULD_WONT_OR_TBD} | Draft |

**Stories:** {COUNT} | **Points:** TBD

## Dependencies

- {DEPENDENCY_OR_TBD}

## Acceptance Criteria (EPIC level)

1. {TESTABLE_CRITERION}
2. {TESTABLE_CRITERION}

## Document References

- `{SOURCE_DOCUMENT}` — {SECTION_OR_REQUIREMENT}

## Open Questions

1. {QUESTION — affected field}

## Version History

| Date | Version | Comment | Author |
|------|---------|---------|--------|
| {DATE} | 0.1 | Initial draft | {AUTHOR_OR_TBD} |
