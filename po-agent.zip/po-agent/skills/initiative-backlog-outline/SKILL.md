---
name: initiative-backlog-outline
description: >
  Creates the initiative summary and preliminary EPIC/USER STORY hierarchy for
  the PO orchestration flow, and publishes it to SharePoint after explicit
  approval (COMPLETE OUTLINE). Invoke only from the Product Owner Orchestration
  Agent, after `knowledge-base-usage` has run and INITIATIVE_ID is known.
---

# Initiative Backlog Outline

## Purpose
Transform an initiative into:
- A concise initiative summary
- A preliminary list of epics
- A preliminary list of user-story titles, each assigned to exactly one epic
- A short list of gaps or assumptions affecting the decomposition

After the user approves it with `COMPLETE OUTLINE`, publish the outline to
SharePoint through `PO_FLOW_CREATE_NEW_PROJECT`.

This is a starting point for backlog discovery. It does not create
acceptance criteria, estimates, priorities, technical designs or delivery
commitments.

## Inputs (provided by the orchestrator)
- `INITIATIVE_ID` — required. If missing, stop immediately and return
  `STATUS: FAILED — missing INITIATIVE_ID`. Do not analyse, do not call any flow.
- `INITIATIVE_DOCUMENT` — required.
- `GUIDELINES` — output of `knowledge-base-usage`. Apply them to epic
  boundaries, naming and story titles. If missing or `NOT FOUND`, continue and
  record it under Key Gaps and Assumptions.
- Optional: `CURRENT_OUTLINE` + `REQUESTED_CHANGES` → Revise mode.
- Optional: `MODE = PUBLISH` + `APPROVED_OUTLINE` → Publish mode.

## Modes
| Mode | When | Action |
|---|---|---|
| Draft | No CURRENT_OUTLINE, no PUBLISH | Steps 1–7, show output, no flow call |
| Revise | CURRENT_OUTLINE + REQUESTED_CHANGES | Apply changes, re-run Step 7, show output, no flow call |
| Publish | MODE = PUBLISH (after `COMPLETE OUTLINE`) | Step 8 only |

Never call `PO_FLOW_CREATE_NEW_PROJECT` in Draft or Revise mode.

## Procedure

### Step 1: Understand the initiative
Read the complete initiative before generating anything. Identify the business
problem, intended outcome, scope boundary, primary actors, major capabilities,
end-to-end process stages, data and integration needs, cross-cutting controls,
operational needs, explicit exclusions and unresolved decisions.
Do not treat headings alone as evidence; use the content beneath them.

### Step 2: Initiative summary
Write a 120–220 word narrative covering the problem, intended outcome, in-scope
capability areas, main actors, key exclusions and major uncertainties.
Consolidate; do not repeat the source.

### Step 3: Candidate epics
Group related capabilities into coherent, outcome-oriented epics. An epic must:
- Represent a meaningful business capability or end-to-end outcome
- Be understandable without the source document
- Be broader than a single feature or screen
- Contain at least two credible user stories where possible
- Not duplicate another epic and stay inside scope
- Include cross-cutting areas (security, privacy, data migration, integration,
  reporting, accessibility, service operation) only when materially required

Do not turn every requirement, heading, use case or system into an epic.

### Step 4: Epic IDs
Format `EPIC-001`, `EPIC-002`, … — unique, sequential, no gaps, starting at
`EPIC-001`. Each epic has an ID, a 3–9 word title and a one-sentence scope.
Avoid vague titles (Platform, Administration, Phase 1, Other Requirements).

### Step 5: Preliminary user-story titles
For each epic, the minimum set of titles that conveys its functional scope.
Each title: one recognisable user or system outcome, action-oriented, no
unrelated "and", no UI or implementation assumptions, distinct from other
titles, mapped to exactly one epic.
Do not write the full "As a… I want… so that…" form, acceptance criteria,
estimates, priorities, sprints, dependencies, tasks or test cases.

Good: "Approve an employee enrolment request", "Retry a failed training-record import".
Weak: "Manage training", "Build API", "Handle data".

### Step 6: User-story IDs
Format `US-001`, `US-002`, … — globally unique across all epics, sequential,
never restarting within an epic. Every story has a valid parent epic.

### Step 7: Validate the hierarchy
Verify: unique epic and story IDs; every parent exists; each story in exactly
one epic; every epic has at least one story; sequential IDs; no duplicate or
near-duplicate titles; titles are outcomes, not tasks; everything within
scope; out-of-scope items excluded; uncertain rules not presented as facts.
Fix any issue before responding.

### Revise mode rules
- Apply only the requested changes; keep everything else unchanged.
- Keep existing IDs stable. New items take the next free ID. Never reuse a
  removed ID; gaps caused by removals are allowed in Revise mode.
- Re-run Step 7 (except the no-gaps check) and update the Relationship Check.

### Step 8: Publish (Publish mode only)
1. Use `APPROVED_OUTLINE` exactly as last shown to the user. Do not regenerate,
   reformat, shorten or rephrase it.
2. Call `PO_FLOW_CREATE_NEW_PROJECT` with:
   - `text` → INITIATIVE_ID
   - `text_1` → APPROVED_OUTLINE (all sections, real line breaks preserved)
3. Return the result (see Publish result).

## Handling uncertainty
Use the initiative as the source of truth. Do not invent actors, business
rules, approval levels, country rules, legal requirements, integration
products, retention periods, service levels, volumes, priorities, dates or
architecture. When a detail is missing, use a neutral title and record the gap
(write "Evaluate an exemption request", not "Approve exemption requests within
two working days" unless the source says so). If the input is too thin for a
credible decomposition, say so instead of padding.
If several initiative versions are provided, use the latest clearly identified
one and state that choice under Key Gaps and Assumptions.

## Output format (Draft and Revise modes)
Return exactly this, then ask the user to review it and to type
`COMPLETE OUTLINE` to approve:

# Initiative Summary — {INITIATIVE_ID}
**Initiative:** {name}

{120–220 word summary}

**Primary actors:** {comma-separated list}
**In scope:** {concise list}
**Out of scope:** {concise list}

# Preliminary Backlog

## EPIC-001 — {Epic title}
**Scope:** {one sentence}
- US-001 — {User-story title}
- US-002 — {User-story title}

## EPIC-002 — {Epic title}
**Scope:** {one sentence}
- US-003 — {User-story title}

# Relationship Check
- Epics: {n}
- User stories: {n}
- Orphan user stories: 0
- Duplicate IDs: 0
- Stories assigned to multiple epics: 0

# Key Gaps and Assumptions
- {gap}

(If none: "No material gaps affecting this preliminary decomposition were identified.")

## Publish result (Publish mode)
Return to the orchestrator, outside the outline content:

STATUS: SUCCESS | FAILED — {error returned by the flow}
FOLDER_PATH: {path or link returned by the flow}

Never report success unless the flow explicitly returned success.

## Quality rules
- Concise and business-readable.
- Language: use `ARTEFACT_LANGUAGE` if the orchestrator provides it; otherwise
  British English. Preserve the initiative's domain terminology.
- Prefer business outcomes over software components; do not inflate the backlog.
- Never expose sensitive personal, confidential or regulated information
  unnecessarily.
