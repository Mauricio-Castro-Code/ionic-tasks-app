---
name: save-artifact-to-sharepoint
description: >
  Persists an approved EPIC or USER STORY as a Markdown file in the
  initiative's SharePoint folder through PO_FLOW_CREATE_DOCUMENT. Invoke ONLY
  from the Product Owner Orchestration Agent after the user typed exactly
  COMPLETE EPIC or COMPLETE USER STORY. Never activate from generic requests
  such as "save", "publish" or "upload".
---

# Save Artefact to SharePoint

## Purpose
Save the approved artefact exactly as approved and report a verifiable result
to the orchestrator. Do not regenerate, summarise, rewrite or improve it.

## Inputs (provided by the orchestrator)
- `ARTEFACT_TYPE` — `EPIC` or `USER_STORY`.
- `ARTEFACT_CONTENT` — the approved draft (the orchestrator's CURRENT_DRAFT).
  This is the only source of content. Never search the conversation for it.
- `ARTEFACT_ID` — e.g. `EPIC-001`, `US-003`.
- `ARTEFACT_TITLE` — the artefact title.
- `FOLDER_PATH` — the initiative folder returned by `PO_FLOW_CREATE_NEW_PROJECT`
  or `PO_FLOW_CONTINUE_INITIATIVE`.

## Validation (stop on the first failure, do not call the flow)
1. Any input missing → `STATUS: FAILED — missing input: <name>`.
   Do not ask the user and do not invent values.
2. Type mismatch → `STATUS: FAILED — type mismatch`:
   - EPIC content must start with `# EPIC — {ARTEFACT_ID}`.
   - USER_STORY content must start with `# USER STORY — {ARTEFACT_ID}`.
3. Strip anything before that first heading (e.g. an introductory sentence)
   and any trailing chat text (e.g. "To save this Epic type…"). Do not change
   anything else.

## Build the target
- **Folder:** FOLDER_PATH + `EPICS/` for EPIC, or + `USER STORIES/` for
  USER_STORY. Collapse repeated slashes (`//` → `/`) and keep a single
  trailing `/`.
- **File name:** `{ARTEFACT_ID}-{TITLE}.md`
  - TITLE: spaces → hyphens; remove `" * : < > ? / \ | # %`; collapse repeated
    hyphens; trim leading/trailing dots, spaces and hyphens; keep it concise.
  - Examples: `EPIC-001-Customer-Onboarding.md`,
    `US-003-Search-Published-Training-Catalogue.md`.
  - Always `.md`. Never a timestamp, never `.docx`.

## Write
Call `PO_FLOW_CREATE_DOCUMENT` with:
- `Document text` → ARTEFACT_CONTENT (after step 3), UTF-8, with real line
  breaks preserved.
- `Document ID` → the file name built above, including `.md`.
- `Folder Path` → the folder built above.

## Structure preservation
Keep headings, section order, lists, tables, checklists, code blocks,
acceptance criteria, Given / When / Then, links and emphasis exactly as they
are. Do not fix grammar, add or remove sections, renumber, add a cover page,
a summary, a timestamp or a confirmation message.

## Result (always return to the orchestrator)
- Flow success:
  STATUS: SUCCESS
  FILE: {file name}
  PATH: {folder or link returned by the flow}
- Flow error:
  STATUS: FAILED — {error returned by the flow}

Never report success unless the flow explicitly returned success.
